@echo off
setlocal
cd /d "%~dp0"
title JARVIS STARTER - SAFE UNINSTALL
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Mode Uninstall
if errorlevel 1 echo Uninstall did not complete. See setup.log.
pause
