@echo off
setlocal
cd /d "%~dp0"
title JARVIS STARTER - REPAIR
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Mode Repair
if errorlevel 1 (
  echo.
  echo REPAIR DID NOT COMPLETE. Read setup.log for the diagnostic details.
  pause
  exit /b 1
)
echo.
echo JARVIS repair and real AI health checks completed successfully.
pause
