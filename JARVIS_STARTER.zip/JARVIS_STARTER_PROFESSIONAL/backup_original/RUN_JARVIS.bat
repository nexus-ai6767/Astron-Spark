@echo off
setlocal
cd /d "%~dp0"
set JARVIS_OLLAMA_MODEL=qwen2.5:1.5b
set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
if not exist "%OLLAMA_EXE%" set "OLLAMA_EXE=%LOCALAPPDATA%\Ollama\ollama.exe"
if not exist "%OLLAMA_EXE%" (
  for /f "delims=" %%I in ('where ollama.exe 2^>nul') do if not defined OLLAMA_EXE set "OLLAMA_EXE=%%I"
)
if not exist "%OLLAMA_EXE%" (
  echo Ollama was not found. Run INSTALL_JARVIS.bat first.
  pause
  exit /b 1
)
set "PYRUN=python"
where py >nul 2>nul && set "PYRUN=py -3"
%PYRUN% -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=2)" >nul 2>&1
if errorlevel 1 start "Ollama Service" /min "%OLLAMA_EXE%" serve
set /a WAIT=0
:WAIT_SERVER
%PYRUN% -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=2)" >nul 2>&1
if not errorlevel 1 goto START_APP
set /a WAIT+=1
if %WAIT% GEQ 20 (
  echo Ollama service did not start. Run INSTALL_JARVIS.bat or inspect setup.log.
  pause
  exit /b 1
)
timeout /t 2 /nobreak >nul
goto WAIT_SERVER
:START_APP
%PYRUN% main.py
if errorlevel 1 pause
