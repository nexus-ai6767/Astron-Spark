JARVIS STARTER - ONE CLICK EDITION
=================================

WHAT'S NEW
----------
- INSTALL_JARVIS.bat: guided one-click setup for Python packages, Ollama,
  the local Qwen model, and a real model-response test.
- RUN_JARVIS.bat: starts the Ollama service when needed and launches JARVIS.
- start_jarvis.bat: compatibility shortcut that calls RUN_JARVIS.bat.
- Default local model: qwen2.5:1.5b (instead of qwen3:4b).

FIRST-TIME SETUP
----------------
1. Extract the complete ZIP to a normal folder, such as Desktop\JARVIS_STARTER.
2. Keep an internet connection available for the first setup.
3. Double-click INSTALL_JARVIS.bat.
4. If Python or Ollama is missing, the setup tries to install it. Windows may
   show an installer or permission prompt; follow the on-screen instructions.
5. Wait for the model download and final model-response test to finish.
6. Double-click RUN_JARVIS.bat to open JARVIS.

IMPORTANT
---------
- This installer is for Windows 10/11 64-bit.
- The first setup needs internet. After the model and Python packages are
  installed, local AI inference can run without internet.
- qwen2.5:1.5b is a small starter model. Response quality and speed depend on
  the computer's RAM, CPU, and available resources.
- Ollama and Python are third-party software. Their own installers and licences
  apply. This ZIP does not bundle their installers or model weights.
- The setup script checks that Ollama can generate a real response; merely
  finding ollama.exe is not considered a successful installation.
- Setup logs are saved as setup.log in this folder.
- If setup stops, read the final error and setup.log, fix the stated issue,
  then run INSTALL_JARVIS.bat again. Downloaded model layers are normally reused.

MANUAL FALLBACK
---------------
Install Python 3.11+ from https://www.python.org/downloads/windows/ and
Ollama from https://ollama.com/download/windows, then run INSTALL_JARVIS.bat.

FEATURES IN THIS STARTER
------------------------
- Text chat with local Ollama AI
- Optional microphone input and text-to-speech
- Notes and simple saved memory
- Basic website/app commands
- Futuristic desktop HUD
