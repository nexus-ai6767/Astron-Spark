@echo off
call "%~dp0RUN_JARVIS.bat"
