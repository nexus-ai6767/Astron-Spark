@echo off
setlocal
cd /d "%~dp0"
title JARVIS STARTER - ONE CLICK SETUP
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 (
  echo.
  echo Setup ended with an error. See setup.log for details.
  pause
  exit /b 1
)
echo.
echo Setup finished.
pause
