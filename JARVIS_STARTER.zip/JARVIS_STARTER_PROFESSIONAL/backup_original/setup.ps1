$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Log = Join-Path $Root 'setup.log'
Start-Transcript -Path $Log -Append | Out-Null

function Say($Message) { Write-Host "`n==> $Message" -ForegroundColor Cyan }
function Find-Ollama {
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
        (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),
        (Join-Path $env:ProgramFiles 'Ollama\ollama.exe')
    )
    $cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($cmd) { $candidates += $cmd.Source }
    foreach ($p in $candidates) { if ($p -and (Test-Path $p)) { return $p } }
    return $null
}
function Test-OllamaRunner($Exe) {
    $dir = Split-Path -Parent $Exe
    $checks = @(
        (Join-Path $dir 'llama-server.exe'),
        (Join-Path $dir 'lib\ollama\llama-server.exe'),
        (Join-Path $dir 'ollama\lib\ollama\llama-server.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\lib\ollama\llama-server.exe')
    )
    foreach ($p in $checks) { if (Test-Path $p) { return $true } }
    # Some installer builds keep runner files in versioned subfolders.
    $found = Get-ChildItem -Path $dir -Filter 'llama-server.exe' -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    return [bool]$found
}
function Start-OllamaServer($Exe) {
    try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 | Out-Null; return } catch {}
    Say 'Starting the local Ollama service'
    Start-Process -FilePath $Exe -ArgumentList 'serve' -WindowStyle Hidden
    for ($i=0; $i -lt 30; $i++) {
        Start-Sleep -Seconds 2
        try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 | Out-Null; return } catch {}
    }
    throw 'Ollama service did not start. Check setup.log and restart Windows if Ollama was just installed.'
}

try {
    Say 'Checking Windows and internet connection'
    if ([Environment]::OSVersion.Platform -ne 'Win32NT') { throw 'This installer supports Windows only.' }
    Invoke-WebRequest -Uri 'https://ollama.com' -Method Head -TimeoutSec 15 | Out-Null

    Say 'Checking Python 3.11 or newer'
    $Py = $null
    foreach ($candidate in @('py','python')) {
        $c = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($c) {
            try {
                $v = & $candidate --version 2>&1
                if ($LASTEXITCODE -eq 0 -and $v -match 'Python\s+(\d+)\.(\d+)') {
                    if ([int]$Matches[1] -gt 3 -or ([int]$Matches[1] -eq 3 -and [int]$Matches[2] -ge 11)) { $Py = $candidate; break }
                }
            } catch {}
        }
    }
    if (-not $Py) {
        Say 'Python 3.11+ was not found. Trying Windows Package Manager'
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if ($winget) {
            & winget install --id Python.Python.3.11 -e --scope user --silent --accept-package-agreements --accept-source-agreements
            if ($LASTEXITCODE -ne 0) { throw 'Python installation through winget failed. Install Python 3.11+ from https://www.python.org/downloads/windows/ and run this installer again.' }
        } else { throw 'Python 3.11+ is missing and winget is unavailable. Install Python 3.11+ from https://www.python.org/downloads/windows/, enable Add Python to PATH, then run this installer again.' }
        $env:Path += ";$env:LOCALAPPDATA\Programs\Python\Python311;$env:LOCALAPPDATA\Programs\Python\Python311\Scripts"
        $Py = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } else { 'python' }
    }
    Write-Host "Using Python: $Py"

    Say 'Checking Ollama installation'
    $Ollama = Find-Ollama
    if (-not $Ollama) {
        Say 'Ollama was not found. Downloading the official Windows installer'
        $installer = Join-Path $env:TEMP 'OllamaSetup.exe'
        Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $installer
        Start-Process -FilePath $installer -Wait
        $env:Path += ";$env:LOCALAPPDATA\Programs\Ollama"
        $Ollama = Find-Ollama
    }
    if (-not $Ollama) { throw 'Ollama was not detected after installation. Install it from https://ollama.com/download/windows and run setup again.' }
    Write-Host "Found Ollama: $Ollama"

    if (-not (Test-OllamaRunner $Ollama)) {
        Say 'Ollama runner files appear incomplete. Repairing with the official installer'
        $installer = Join-Path $env:TEMP 'OllamaSetup.exe'
        Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $installer
        Start-Process -FilePath $installer -Wait
        $Ollama = Find-Ollama
        if (-not $Ollama -or -not (Test-OllamaRunner $Ollama)) {
            throw 'Ollama runner files are still missing after repair. Please restart Windows, then run INSTALL_JARVIS.bat again. No application files were deleted.'
        }
    }

    Say 'Installing JARVIS Python packages'
    if ($Py -eq 'py') { & py -3 -m pip install --upgrade pip; & py -3 -m pip install -r (Join-Path $Root 'requirements.txt') }
    else { & python -m pip install --upgrade pip; & python -m pip install -r (Join-Path $Root 'requirements.txt') }
    if ($LASTEXITCODE -ne 0) { throw 'Python package installation failed. Check your internet connection and setup.log, then rerun this installer.' }

    Say 'Starting Ollama and downloading the JARVIS model (qwen2.5:1.5b)'
    Start-OllamaServer $Ollama
    & $Ollama pull 'qwen2.5:1.5b'
    if ($LASTEXITCODE -ne 0) { throw 'Model download failed. Keep internet connected and run INSTALL_JARVIS.bat again; Ollama can reuse already downloaded layers.' }

    Say 'Verifying that the model can actually generate a response'
    $body = @{ model = 'qwen2.5:1.5b'; prompt = 'Reply with the single word READY.'; stream = $false } | ConvertTo-Json
    $response = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/generate' -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 180
    if (-not $response.response) { throw 'Ollama did not return a model response. Check setup.log.' }

    Say 'Setup completed successfully'
    Write-Host 'JARVIS is ready. Use RUN_JARVIS.bat to launch it.' -ForegroundColor Green
    Write-Host "Model: qwen2.5:1.5b | Ollama: $Ollama"
} catch {
    Write-Host "`nSETUP ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Details saved to: $Log" -ForegroundColor Yellow
    Stop-Transcript | Out-Null
    exit 1
}
Stop-Transcript | Out-Null
exit 0
