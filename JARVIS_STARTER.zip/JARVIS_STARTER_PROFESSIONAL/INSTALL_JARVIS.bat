@echo off
setlocal
cd /d "%~dp0"
title JARVIS STARTER - INSTALLER
where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo PowerShell was not found. Windows PowerShell 5.1 is required.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Mode Install
if errorlevel 1 (
  echo.
  echo INSTALLATION FAILED. Read the message above and setup.log.
  pause
  exit /b 1
)
echo.
echo JARVIS installation and AI health check completed successfully.
echo Double-click RUN_JARVIS.bat when you want to start JARVIS.
pause
