J.A.R.V.I.S STARTER — PROFESSIONAL ONE-CLICK WINDOWS PACKAGE
============================================================

QUICK START
-----------
1. Extract the entire ZIP into a normal writable folder (do not run from inside the ZIP).
2. Connect to the internet for the first installation.
3. Double-click INSTALL_JARVIS.bat and allow the normal Windows prompts.
4. Wait for Python packages, Ollama, the model and the real AI test to finish.
5. Double-click RUN_JARVIS.bat whenever you want to use JARVIS.

RECOVERY
--------
- REPAIR_JARVIS.bat checks Python, the project virtual environment, Ollama, its model
  runner, the local API, the configured model and a real generation request.
- INSTALL_JARVIS.bat can be safely rerun. Existing model downloads are retained by Ollama.
- UNINSTALL_JARVIS.bat removes only this project's .venv after you type REMOVE.
  It does NOT uninstall Ollama, delete Ollama models, or remove JARVIS notes/memory.
- Detailed installer and launcher diagnostics: setup.log

WHAT THE INSTALLER DOES
-----------------------
- Supports Windows 10/11 (64-bit recommended), with compatible Python 3.11–3.13.
- Uses an isolated .venv; it does not install project packages into global Python.
- If Python is missing, it tries the official Python 3.12 package through winget.
- If Ollama is missing or its required llama-server.exe runner is absent, it downloads
  the installer only from https://ollama.com/download/OllamaSetup.exe and requires a
  valid Authenticode signature whose signer identifies Ollama before execution.
- Inspects the Ollama install tree and reports CPU/GPU-related runtime assets separately.
  GPU libraries are optional; a real model generation test is the final runner check.
- Uses the configured model from jarvis_config.json (default qwen2.5:1.5b).
- Checks the API, installed model and actual generated response before declaring success.

CONFIGURATION
-------------
Edit jarvis_config.json to change the model or local Ollama base URL. The installer,
launcher and JARVIS application all read the same model configuration. Keep the JSON valid.

PRESERVATION & SAFETY
---------------------
- The existing Tkinter UI, assistant commands, voice/TTS logic, notes and memory remain.
- Original files modified by this package are copied into backup_original\.
- No script deletes the Ollama model directory or JARVIS memory/notes.
- Ollama is never silently uninstalled. The uninstall script only removes .venv.
- If Ollama is running but its API is unresponsive, the launcher does not start a duplicate
  server; close Ollama from its tray menu and use REPAIR_JARVIS.bat.
- Interrupted pip/model downloads can be retried. Pip and Ollama reuse available caches/layers.

IMPORTANT NOTES
---------------
- First installation needs internet. Local inference can work offline after setup.
- The default Qwen 2.5 1.5B model requires adequate memory and disk; performance varies.
- Python 3.14 is intentionally not selected because some native audio dependencies may
  not yet provide compatible wheels. Use Python 3.11, 3.12 or 3.13.
- Windows PowerShell 5.1 is used. PowerShell script execution is scoped to this process
  via -ExecutionPolicy Bypass; the system execution policy is not changed.
- Ollama may show its own installer UI and Windows security prompts.
- This package cannot guarantee every PC's GPU driver compatibility. If CPU execution
  works but GPU assets are absent, Ollama may use CPU mode.

MANUAL SUPPORT
--------------
Official Ollama Windows download: https://ollama.com/download/windows
Official Python Windows downloads: https://www.python.org/downloads/windows/
If setup fails, share setup.log (remove any personal paths you do not wish to share).
