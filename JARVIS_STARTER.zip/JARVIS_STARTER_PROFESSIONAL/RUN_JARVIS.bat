@echo off
setlocal
cd /d "%~dp0"
title JARVIS STARTER - LAUNCHER
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Mode Launch
if errorlevel 1 (
  echo.
  echo JARVIS could not start. See setup.log and follow the recovery message.
  pause
  exit /b 1
)
