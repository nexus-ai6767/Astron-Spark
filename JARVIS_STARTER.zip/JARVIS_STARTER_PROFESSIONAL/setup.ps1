﻿param(
    [ValidateSet('Install','Repair','Launch','Uninstall')]
    [string]$Mode = 'Install'
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Log = Join-Path $Root 'setup.log'
$TranscriptStarted = $false
$script:OllamaRepairAttempted = $false
try { Start-Transcript -Path $Log -Append | Out-Null; $TranscriptStarted = $true } catch {}

function Say([string]$Message) { Write-Host "`n[ JARVIS ] $Message" -ForegroundColor Cyan }
function Good([string]$Message) { Write-Host "  [OK] $Message" -ForegroundColor Green }
function Warn([string]$Message) { Write-Host "  [!] $Message" -ForegroundColor Yellow }
function Fail([string]$Message) { throw $Message }
function Load-Config {
    $file = Join-Path $Root 'jarvis_config.json'
    if (-not (Test-Path $file)) { Fail 'jarvis_config.json is missing. Extract the complete JARVIS ZIP again.' }
    return (Get-Content -Raw -LiteralPath $file | ConvertFrom-Json)
}
$Config = Load-Config
$Model = [string]$Config.model
$BaseUrl = ([string]$Config.ollama_base_url).TrimEnd('/')
$ApiTags = "$BaseUrl/api/tags"
$ApiGenerate = "$BaseUrl/api/generate"

function Test-Internet {
    try { $r = Invoke-WebRequest -Uri 'https://ollama.com' -Method Head -TimeoutSec 15 -UseBasicParsing; return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) } catch { return $false }
}
function Find-Python {
    $candidates = @()
    $pyCmd = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($pyCmd) {
        try {
            $registered = & $pyCmd.Source -0p 2>$null
            foreach ($line in $registered) {
                if ("$line" -match '([A-Za-z]:\\.*python(?:\.exe)?)\s*$') {
                    $candidatePath = $Matches[1]
                    if (Test-Path -LiteralPath $candidatePath) { $candidates += [pscustomobject]@{Exe=$candidatePath; Args=@()} }
                }
            }
        } catch {}
    }
    $pyCmd = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($pyCmd -and $pyCmd.Source -notmatch '(?i)\\WindowsApps\\') { $candidates += [pscustomobject]@{Exe=$pyCmd.Source; Args=@()} }
    $localPython = Join-Path $env:LOCALAPPDATA 'Programs\Python'
    if (Test-Path $localPython) {
        Get-ChildItem $localPython -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^Python3(11|12|13)$' } | ForEach-Object {
            $exe = Join-Path $_.FullName 'python.exe'; if (Test-Path $exe) { $candidates += [pscustomobject]@{Exe=$exe; Args=@()} }
        }
    }
    foreach ($c in $candidates) {
        try {
            $versionArgs = @($c.Args) + @('--version')
            $v = & $c.Exe @versionArgs 2>&1
            if ($LASTEXITCODE -eq 0 -and "$v" -match 'Python\s+3\.(\d+)\.(\d+)') {
                $minor=[int]$Matches[1]
                if ($minor -ge [int]$Config.python_min_minor -and $minor -le [int]$Config.python_max_minor) {
                    return [pscustomobject]@{Exe=$c.Exe; Args=$c.Args; Version="$v"}
                }
            }
        } catch {}
    }
    return $null
}
function Ensure-Python {
    Say 'Checking compatible Python (3.11–3.13)'
    $script:Python = Find-Python
    if (-not $script:Python) {
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) { Fail 'Compatible Python 3.11–3.13 was not found and Windows Package Manager (winget) is unavailable. Install Python 3.12 from https://www.python.org/downloads/windows/, then run this installer again.' }
        Warn 'Python 3.12 is missing. Windows may display an installation confirmation.'
        & $winget.Source install --id ([string]$Config.python_install_package) -e --scope user --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { Fail 'Python installation through winget did not complete. Install Python 3.12 from python.org and rerun.' }
        $env:Path = "$env:LOCALAPPDATA\Programs\Python\Python312;$env:LOCALAPPDATA\Programs\Python\Python312\Scripts;$env:LOCALAPPDATA\Programs\Python\Launcher;$env:Path"
        $script:Python = Find-Python
        if (-not $script:Python) { Fail 'Python installer finished but a compatible interpreter was not detected. Restart Windows and rerun INSTALL_JARVIS.bat.' }
    }
    Good "Using $($script:Python.Version)"
}
function Find-Ollama {
    $paths = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
        (Join-Path $env:ProgramFiles 'Ollama\ollama.exe'),
        (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe')
    )
    $cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($cmd) { $paths += $cmd.Source }
    foreach ($path in ($paths | Select-Object -Unique)) { if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) { return (Resolve-Path -LiteralPath $path).Path } }
    return $null
}
function Test-RunnerExecutable([string]$Path) {
    try {
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
        if ((Get-Item -LiteralPath $Path).Length -lt 1MB) { return $false }
        $stream = [System.IO.File]::OpenRead($Path)
        try {
            [byte[]]$header = New-Object byte[] 2
            $read = $stream.Read($header, 0, 2)
            return ($read -eq 2 -and $header[0] -eq 0x4D -and $header[1] -eq 0x5A)
        } finally { $stream.Dispose() }
    } catch { return $false }
}
function Get-RunnerReport([string]$Exe) {
    $installDir = Split-Path -Parent $Exe
    $server = @()
    foreach ($candidate in @(
        (Join-Path $installDir 'lib\ollama\llama-server.exe'),
        (Join-Path $installDir 'llama-server.exe'),
        (Join-Path $installDir 'build\lib\ollama\llama-server.exe'),
        (Join-Path $installDir 'dist\windows-amd64\lib\ollama\llama-server.exe'),
        (Join-Path $installDir 'dist\windows_amd64\lib\ollama\llama-server.exe')
    )) { if (Test-RunnerExecutable $candidate) { $server += $candidate } }
    if (-not $server) {
        try { $server += (Get-ChildItem -LiteralPath $installDir -Filter 'llama-server.exe' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { Test-RunnerExecutable $_.FullName } | Select-Object -ExpandProperty FullName -First 3) } catch {}
    }
    $lib = Join-Path $installDir 'lib\ollama'
    $assets = @(); if (Test-Path $lib) { $assets = @(Get-ChildItem $lib -Force -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) }
    $cpu = [bool](@($assets | Where-Object { $_ -match '(?i)cpu|ggml' }).Count)
    $gpu = [bool](@($assets | Where-Object { $_ -match '(?i)cuda|rocm|vulkan|metal|hip|mlx' }).Count)
    return [pscustomobject]@{ServerPaths=@($server | Select-Object -Unique); CpuAssets=$cpu; GpuAssets=$gpu; Library=$lib; AssetNames=$assets}
}
function Download-OfficialOllamaInstaller {
    if (-not (Test-Internet)) { Fail 'Internet connection is unavailable. Connect to the internet and rerun; existing files and models were left untouched.' }
    $url = [string]$Config.ollama_installer_url
    if ($url -notmatch '^https://ollama\.com/') { Fail 'The configured Ollama installer URL is not on the official ollama.com domain. Refusing download.' }
    $installer = Join-Path $env:TEMP ('OllamaSetup-JARVIS-' + [guid]::NewGuid().ToString('N') + '.exe')
    Say 'Downloading the official Ollama Windows installer'
    Invoke-WebRequest -Uri $url -OutFile $installer -TimeoutSec 180 -UseBasicParsing
    if (-not (Test-Path $installer) -or (Get-Item $installer).Length -lt 1MB) { Remove-Item $installer -Force -ErrorAction SilentlyContinue; Fail 'The downloaded Ollama installer is missing or unexpectedly small. No installer was run.' }
    $sig = Get-AuthenticodeSignature -FilePath $installer
    if ($sig.Status -ne 'Valid' -or ($sig.SignerCertificate.Subject -notmatch '(?i)Ollama')) {
        $hash = (Get-FileHash $installer -Algorithm SHA256).Hash
        Remove-Item $installer -Force -ErrorAction SilentlyContinue
        Fail "Ollama installer signature could not be verified as valid and signed by Ollama. Refusing to execute it. SHA256 observed: $hash"
    }
    Good 'Official installer download and Authenticode signature verified'
    return $installer
}
function Install-OrRepair-Ollama {
    $exe = Find-Ollama
    $mustInstall = $false
    if (-not $exe) { Say 'Ollama is not installed'; $mustInstall = $true }
    else {
        Say 'Inspecting existing Ollama installation and runner files'
        try { $version = (& $exe --version 2>&1 | Out-String).Trim(); Good "Ollama executable responds: $version" } catch { Warn 'Ollama executable did not return a version.' }
        $report = Get-RunnerReport $exe
        if ($report.ServerPaths.Count -eq 0) {
            Warn 'llama-server.exe was not found in the detected installation tree. This is the required model runner; an official repair is needed.'
            $mustInstall = $true
        } else {
            Good "llama-server.exe found: $($report.ServerPaths[0])"
            Write-Host "  CPU-related runtime assets detected: $($report.CpuAssets) | GPU-related assets detected: $($report.GpuAssets)"
            if (-not $report.CpuAssets) { Warn 'CPU-specific asset names were not identified. Runner presence will be validated with a real model generation test.' }
            if (-not $report.GpuAssets) { Write-Host '  GPU-specific assets not identified; CPU execution may still be supported.' -ForegroundColor DarkGray }
        }
    }
    if ($mustInstall) {
        $script:OllamaRepairAttempted = $true
        $installer = Download-OfficialOllamaInstaller
        Say 'Running official Ollama installer / repair (existing model directory is not targeted)'
        $proc = Start-Process -FilePath $installer -Wait -PassThru
        Remove-Item $installer -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
        $exe = Find-Ollama
        if (-not $exe) { Fail "Ollama installer exited with code $($proc.ExitCode), but ollama.exe was not detected. Open https://ollama.com/download/windows and complete installation, then run REPAIR_JARVIS.bat." }
        $report = Get-RunnerReport $exe
        if ($report.ServerPaths.Count -eq 0) { Fail 'Ollama repair ran, but llama-server.exe is still missing. The installation is incomplete. Keep your model directory; reinstall Ollama from the official Windows download page, then run REPAIR_JARVIS.bat. JARVIS did not delete Ollama data.' }
        Good 'Ollama executable and llama-server runner verified after installer repair'
    }
    $script:OllamaExe = $exe
    return $exe
}
function Test-OllamaApi {
    try { Invoke-RestMethod -Uri $ApiTags -TimeoutSec 3 | Out-Null; return $true } catch { return $false }
}
function Ensure-OllamaServer {
    if (Test-OllamaApi) { Good 'Ollama local API is already responding'; return }
    # Allow the official desktop app/service a short startup window before deciding whether a duplicate is present.
    for ($warmup=0; $warmup -lt 10; $warmup++) { Start-Sleep -Seconds 2; if (Test-OllamaApi) { Good 'Ollama local API became ready'; return } }
    $existing = @(Get-Process -Name 'ollama','ollama app' -ErrorAction SilentlyContinue)
    if ($existing.Count -gt 0) { Fail 'Ollama processes are already running, but the local API is not responding. To avoid starting a duplicate server, JARVIS did not launch another. Quit Ollama from its tray icon, then run REPAIR_JARVIS.bat. Check %LOCALAPPDATA%\Ollama\server.log.' }
    Say 'Starting Ollama service'
    Start-Process -FilePath $script:OllamaExe -ArgumentList 'serve' -WindowStyle Hidden
    for ($i=0; $i -lt 30; $i++) { Start-Sleep -Seconds 2; if (Test-OllamaApi) { Good 'Ollama API is ready at 127.0.0.1:11434'; return } }
    Fail 'Ollama service did not respond on 127.0.0.1:11434 within 60 seconds. Check %LOCALAPPDATA%\Ollama\server.log, then run REPAIR_JARVIS.bat.'
}
function Ensure-Venv {
    $venv = Join-Path $Root '.venv'
    $venvPython = Join-Path $venv 'Scripts\python.exe'
    if (Test-Path $venvPython) {
        try { & $venvPython -c 'import sys; assert sys.version_info >= (3,11) and sys.version_info < (3,14)' 2>$null; if ($LASTEXITCODE -ne 0) { throw 'bad venv' } }
        catch { Say 'Existing virtual environment is damaged or incompatible; recreating only .venv'; Rename-Item $venv ($venv + '.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss')) }
    }
    if (-not (Test-Path $venvPython)) {
        Say 'Creating isolated Python environment'
        $venvArgs = @($script:Python.Args) + @('-m','venv',$venv)
        & $script:Python.Exe @venvArgs
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path $venvPython)) { Fail 'Could not create the project virtual environment. Check disk space and Python installation.' }
    }
    $script:VenvPython = $venvPython
    Say 'Installing project dependencies inside .venv'
    & $venvPython -m ensurepip --upgrade
    if ($LASTEXITCODE -ne 0) { Fail 'Python ensurepip failed. Run REPAIR_JARVIS.bat after repairing Python.' }
    & $venvPython -m pip install --disable-pip-version-check --retries 3 --timeout 45 -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { Fail 'Dependency installation failed. setup.log contains pip output. Rerun REPAIR_JARVIS.bat; completed packages are safely reused.' }
    & $venvPython -m pip check
    if ($LASTEXITCODE -ne 0) { Fail 'Installed Python packages have dependency conflicts. See setup.log and rerun REPAIR_JARVIS.bat.' }
    Good 'Python virtual environment and dependencies verified'
}
function Ensure-Model {
    Say "Checking configured model: $Model"
    $tags = Invoke-RestMethod -Uri $ApiTags -TimeoutSec 10
    $present = @($tags.models | Where-Object { $_.name -eq $Model -or $_.model -eq $Model }).Count -gt 0
    if (-not $present) {
        $modelRoot = if ($env:OLLAMA_MODELS) { $env:OLLAMA_MODELS } else { Join-Path $HOME '.ollama\models' }
        $modelDrive = [System.IO.Path]::GetPathRoot($modelRoot)
        $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($modelDrive.TrimEnd('\'))'" -ErrorAction SilentlyContinue
        $freeGB = if ($disk) { [math]::Round($disk.FreeSpace / 1GB, 1) } else { 0 }
        if ($disk -and $freeGB -lt 3) { Fail "Only $freeGB GB free on the Ollama model drive ($modelDrive). Free at least 3 GB before downloading. Existing models were not touched." }
        Say "Downloading $Model (Ollama displays layer progress below; reruns reuse completed layers)"
        & $script:OllamaExe pull $Model
        if ($LASTEXITCODE -ne 0) { Fail "Model download failed or was interrupted. Keep internet connected and rerun INSTALL_JARVIS.bat; Ollama should reuse completed layers." }
    } else { Good 'Configured model is already installed; download skipped' }
    $body = @{model=$Model; prompt='Reply with the single word READY.'; stream=$false} | ConvertTo-Json -Compress
    Say 'Running a real local model generation test'
    try {
        $result = Invoke-RestMethod -Uri $ApiGenerate -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 240
    } catch {
        $generationError = $_.Exception.Message
        if ($generationError -match '(?i)500|llama-server|runner|server error' -and -not $script:OllamaRepairAttempted) {
            $script:OllamaRepairAttempted = $true
            Warn "Generation failed with a server/runner error. Attempting one official Ollama repair: $generationError"
            $installer = Download-OfficialOllamaInstaller
            $repairProc = Start-Process -FilePath $installer -Wait -PassThru
            Remove-Item $installer -Force -ErrorAction SilentlyContinue
            $script:OllamaExe = Find-Ollama
            if (-not $script:OllamaExe) { Fail 'Official Ollama repair completed but ollama.exe is still missing. Existing model data was not intentionally removed.' }
            $repairReport = Get-RunnerReport $script:OllamaExe
            if ($repairReport.ServerPaths.Count -eq 0) { Fail 'One official repair attempt completed, but a valid llama-server.exe runner is still missing. Contact Ollama support; do not download runner files from unofficial sites.' }
            Ensure-OllamaServer
            try { $result = Invoke-RestMethod -Uri $ApiGenerate -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 240 }
            catch { Fail "Model generation still failed after one official repair attempt: $($_.Exception.Message). Check %LOCALAPPDATA%\Ollama\server.log." }
        } elseif ($generationError -match '(?i)500|llama-server|runner|server error') {
            Fail "Model generation failed after the one allowed official Ollama repair attempt: $generationError. Check %LOCALAPPDATA%\Ollama\server.log."
        } else { Fail "Model generation request failed: $generationError" }
    }
    if (-not $result.response -or [string]::IsNullOrWhiteSpace([string]$result.response)) { Fail 'Ollama API returned no generated text. The model runner may be broken; run REPAIR_JARVIS.bat. Check the Ollama server log.' }
    Good "Model generated a response: $(([string]$result.response).Trim() -replace '\s+',' ' | ForEach-Object { if ($_.Length -gt 100) { $_.Substring(0,100) + '...' } else { $_ } })"
}
function Check-System {
    Say 'Checking Windows, disk space and network'
    if ([Environment]::OSVersion.Platform -ne 'Win32NT') { Fail 'This installer only supports Windows.' }
    if ([Environment]::OSVersion.Version.Major -lt 10) { Fail 'Windows 10 or newer is required.' }
    if (-not [Environment]::Is64BitOperatingSystem) { Fail 'A 64-bit Windows installation is required for the supported Python and Ollama packages.' }
    $drive = [System.IO.Path]::GetPathRoot($Root)
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($drive.TrimEnd('\'))'" -ErrorAction SilentlyContinue
    if ($disk) { $freeGB=[math]::Round($disk.FreeSpace/1GB,1); Write-Host "  Free space on project drive: $freeGB GB"; if ($freeGB -lt [double]$Config.minimum_free_gb) { Fail "At least $($Config.minimum_free_gb) GB free space is recommended on the project drive. Free space and rerun." } }
    if (-not (Test-Internet)) { Fail 'Internet connection check failed. Connect to the internet for initial setup and retry. Existing project data was not changed.' }
    Good 'Windows and internet checks passed'
}

try {
    Write-Host '============================================' -ForegroundColor DarkCyan
    Write-Host '       J.A.R.V.I.S  //  STARTER SETUP       ' -ForegroundColor Cyan
    Write-Host '============================================' -ForegroundColor DarkCyan
    switch ($Mode) {
        'Install' {
            Check-System
            Ensure-Python
            Install-OrRepair-Ollama | Out-Null
            Ensure-OllamaServer
            Ensure-Venv
            Ensure-Model
            Say 'INSTALLATION COMPLETE'
            Write-Host 'JARVIS is ready. Double-click RUN_JARVIS.bat to launch.' -ForegroundColor Green
        }
        'Repair' {
            Check-System
            Ensure-Python
            Install-OrRepair-Ollama | Out-Null
            Ensure-OllamaServer
            Ensure-Venv
            Ensure-Model
            Say 'REPAIR COMPLETE'
            Write-Host 'All configured health checks passed.' -ForegroundColor Green
        }
        'Launch' {
            $script:Python = Find-Python
            if (-not $script:Python) { Fail 'Compatible Python was not found. Run INSTALL_JARVIS.bat first.' }
            $script:OllamaExe = Find-Ollama
            if (-not $script:OllamaExe) { Fail 'Ollama is missing. Run INSTALL_JARVIS.bat or REPAIR_JARVIS.bat.' }
            $report = Get-RunnerReport $script:OllamaExe
            if ($report.ServerPaths.Count -eq 0) { Fail 'Ollama llama-server runner is missing. Run REPAIR_JARVIS.bat to attempt an official repair.' }
            $script:VenvPython = Join-Path $Root '.venv\Scripts\python.exe'
            if (-not (Test-Path $script:VenvPython)) { Fail 'JARVIS virtual environment is missing. Run INSTALL_JARVIS.bat.' }
            Ensure-OllamaServer
            $tags = Invoke-RestMethod -Uri $ApiTags -TimeoutSec 10
            if (@($tags.models | Where-Object { $_.name -eq $Model -or $_.model -eq $Model }).Count -eq 0) { Fail "Configured model '$Model' is not installed. Run REPAIR_JARVIS.bat to download and verify it." }
            Say 'Launching JARVIS desktop application'
            Push-Location $Root
            try { & $script:VenvPython (Join-Path $Root 'main.py'); if ($LASTEXITCODE -ne 0) { Fail "JARVIS exited with code $LASTEXITCODE. See setup.log." } } finally { Pop-Location }
        }
        'Uninstall' {
            Write-Host 'This removes only the JARVIS project virtual environment (.venv).' -ForegroundColor Yellow
            Write-Host 'It will NOT uninstall Ollama, delete downloaded models, or remove notes/memory.' -ForegroundColor Yellow
            $answer = Read-Host 'Type REMOVE to continue'
            if ($answer -ne 'REMOVE') { Write-Host 'Uninstall cancelled.'; break }
            $venv = Join-Path $Root '.venv'
            if (Test-Path $venv) { Remove-Item $venv -Recurse -Force }
            Good 'JARVIS virtual environment removed. Project files and personal data remain.'
        }
    }
} catch {
    Write-Host "`n[SETUP FAILED] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Diagnostic log: $Log" -ForegroundColor Yellow
    Write-Host 'No Ollama models or JARVIS memory/notes were deleted.' -ForegroundColor Yellow
    if ($Mode -eq 'Launch') { Write-Host 'Run INSTALL_JARVIS.bat for first setup or REPAIR_JARVIS.bat for recovery.' -ForegroundColor Yellow }
    if ($TranscriptStarted) { try { Stop-Transcript | Out-Null } catch {} }
    exit 1
}
if ($TranscriptStarted) { try { Stop-Transcript | Out-Null } catch {} }
exit 0
